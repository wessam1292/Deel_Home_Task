package Test;

import com.ahmed.excelizer.ExcelReader;
        import io.github.bonigarcia.wdm.WebDriverManager;
        import org.openqa.selenium.By;
        import org.openqa.selenium.JavascriptExecutor;
        import org.openqa.selenium.WebDriver;
        import org.openqa.selenium.WebElement;
        import org.openqa.selenium.chrome.ChromeDriver;
        import org.openqa.selenium.support.ui.ExpectedConditions;
        import org.openqa.selenium.support.ui.WebDriverWait;
        import org.testng.Assert;
        import org.testng.annotations.BeforeClass;
        import org.testng.annotations.DataProvider;
        import org.testng.annotations.Test;

        import java.util.concurrent.TimeUnit;

public class Deel {

    WebDriver driver;
    public int trials = 0;


    @BeforeClass
    public void Setup() {
        // System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "//Drivers//chromedriver.exe");
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
    }

    @Test
    public void openURL() {
        driver.navigate().to("https://app.deel.training/login");
        WebElement Email = driver.findElement(By.xpath("//input[@name='email']"));
        Email.sendKeys("wessam.gamal1@vodafone.com");

        WebElement password = driver.findElement(By.xpath("//input[@name='password']"));
        password.sendKeys("Wessamwessamnti@92");

        WebElement loginbtn = driver.findElement(By.xpath("//button[@class='button w-100']"));
        loginbtn.click();

        WebElement Cokkie = driver.findElement(By.xpath("//a[@id='CybotCookiebotDialogBodyButtonAccept']"));
        Cokkie.click();


        WebElement xbutton = driver.findElement(By.xpath("//div[@class='deel-ui_whats-new-popup_icon-button']"));
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].scrollIntoView(true);", xbutton);
        xbutton.click();

        WebElement createcontract = driver.findElement(By.cssSelector("a[href='/create']"));
        createcontract.click();

        WebElement fixedrate = driver.findElement(By.xpath("//h4[normalize-space()='Fixed Rate']"));
        fixedrate.click();

        String URL = driver.getCurrentUrl();
        Assert.assertEquals(URL, "https://app.deel.training/create/fixed");

        WebElement Entity = driver.findElement(By.xpath("//div[@class='deel-ui_select_single-value css-1uccc91-singleValue']"));
        String text = Entity.getText();
        System.out.println(text);

        WebElement contractname = driver.findElement(By.name("name"));
        contractname.sendKeys("fixed");

        // WebElement contractortaxresidence = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[4]/div/form/div[2]/div/div[2]/div/div/div/div/div/div[1]"));
        // contractname.sendKeys("Armenia");

        //To wait for element visible

        WebDriverWait wait2 = new WebDriverWait(driver, 15);
       WebElement contractortax = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-qa='contractor-tax-residence']//div[@class='deel-ui_select_value-container css-1hwfws3']")));

        WebElement senioritylevel = driver.findElement(By.xpath("//input[@name='clientLegalEntityId']"));
        JavascriptExecutor executor1 = (JavascriptExecutor) driver;

        //executor.executeScript("arguments[0].scrollIntoView(true);", senioritylevel);
        //senioritylevel.sendKeys("//input[@name='seniorityLevel']");

    }
}